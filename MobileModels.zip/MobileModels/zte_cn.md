# 中兴手机型号汇总

- 汇总范围: 2017 年起上市的机型
- codename: ❌
- 是否包含海外机型: ❌

**中兴天机 7:**

`ZTE A2017`: 中兴天机 7

**中兴天机 7S:**

`ZTE A2018`: 中兴天机 7S

**中兴天机 7 MAX:**

`ZTE C2017`: 中兴天机 7 MAX

**中兴天机 Axon M:**

`Z999`: 中兴天机 Axon M

**中兴天机 Axon 9 Pro:**

`ZTE A2019 Pro`: 中兴天机 Axon 9 Pro

**中兴天机 Axon 10 Pro:**

`ZTE A2020 Pro`: 中兴天机 Axon 10 Pro 4G

`ZTE A2020N2 Pro`: 中兴天机 Axon 10 Pro 5G

**中兴天机 Axon 10s Pro 5G:**

`ZTE A2020 SP`: 中兴天机 Axon 10s Pro 5G

**中兴天机 Axon 11 SE 5G:**

`ZTE 9000N`: 中兴天机 Axon 11 SE 5G

**中兴天机 Axon 11 5G:**

`ZTE A2021`: 中兴天机 Axon 11 5G 公开版

`ZTE A2021H`: 中兴天机 Axon 11 5G 行业版

**中兴天机 Axon 20 5G:**

`ZTE A2121`: 中兴天机 Axon 20 5G

**中兴 Axon 30 / 中兴 Axon 30S:**

`ZTE A2322`: 中兴 Axon 30 5G / 中兴 Axon 30S 5G

**中兴 Axon 30 Pro:**

`ZTE A2022`: 中兴 Axon 30 Pro 5G

**中兴 Axon 30 Ultra:**

`ZTE A2022P`: 中兴 Axon 30 Ultra 5G

**中兴天机 A31:**

`ZTE A2122H`: 中兴天机 A31 5G

**中兴天机 A31 Pro:**

`ZTE A2022H`: 中兴天机 A31 Pro 5G

**中兴天机 A31 Ultra:**

`ZTE A2022P`: 中兴天机 A31 Ultra 5G

**中兴 Axon 40 Pro:**

`ZTE A2023`: 中兴 Axon 40 Pro

**中兴 Axon 40 Ultra:**

`ZTE A2023P`: 中兴 Axon 40 Ultra

**中兴 Axon 50 / 中兴 Axon 50 Ultra:**

`ZTE A2024H`: 中兴 Axon 50 / 中兴 Axon 50 Ultra

**中兴 Axon 60 Ultra:**

`ZTE A2025HL`: 中兴 Axon 60 Ultra

`ZTE A2025H`: 中兴 Axon 60 Ultra 天通版

**中兴天机 A41:**

`ZTE A2023BH`: 中兴天机 A41

**中兴天机 A41 Pro:**

`ZTE A2023`: 中兴天机 A41 Pro

**中兴天机 A41 Ultra:**

`ZTE A2023H`: 中兴天机 A41 Ultra

**中兴天机 A41 Ultra 至尊版:**

`ZTE A2023P`: 中兴天机 A41 Ultra 至尊版

**中兴 S30:**

`ZTE 9030N`: 中兴 S30 5G

**中兴 S30 Pro:**

`ZTE A2122H`: 中兴 S30 Pro 5G

**中兴 S30 SE:**

`ZTE 8030N`: 中兴 S30 SE 5G

**中兴 Blade A2 Plus:**

`ZTE BV0730`: 中兴 Blade A2 Plus

**中兴 Blade A2S:**

`ZTE V0721`: 中兴 Blade A2S

**中兴 Blade A3:**

`ZTE A0616`: 中兴 Blade A3

**中兴 Blade A4:**

`ZTE A0722`: 中兴 Blade A4

**中兴 Blade A7:**

`ZTE A7000`: 中兴 Blade A7

**中兴 Blade A7S:**

`ZTE A7010`: 中兴 Blade A7S

**中兴 Blade V8:**

`ZTE BV0800`: 中兴 Blade V8

**中兴 Blade V8 mini:**

`ZTE BV0850`: 中兴 Blade V8 mini

**中兴 Blade V9:**

`ZTE V0900`: 中兴 Blade V9

**中兴 Blade V10:**

`ZTE V1000`: 中兴 Blade V10

**中兴 Blade 20 Smart:**

`ZTE V1050`: 中兴 Blade 20 Smart

**中兴 Blade 20 5G:**

`ZTE 8012N`: 中兴 Blade 20 5G

**中兴 Blade V2020:**

`ZTE 9000N`: 中兴 Blade V2020

**中兴 Blade V2020 Smart:**

`ZTE 8010`: 中兴 Blade V2020 Smart

**中兴 Blade V2021 5G:**

`ZTE 8012N`: 中兴 Blade V2021 5G

**中兴 ZTE V2022:**

`ZTE 8031`: 中兴 ZTE V2022

**中兴小鲜 4:**

`ZTE BV0701`: 中兴小鲜 4

**中兴小鲜 5:**

`ZTE V0840`: 中兴小鲜 5

**中兴小鲜 5S:**

`ZTE V0920`: 中兴小鲜 5S

**中兴远航 5 plus:**

`ZTE A0620`: 中兴远航 5 plus

**中兴远航 10:**

`ZTE 7530N`: 中兴远航 10

**中兴远航 20 Pro:**

`ZTE 9040N`: 中兴远航 20 Pro

**中兴远航 30:**

`ZTE 7532N`: 中兴远航 30

**中兴远航 30S:**

`ZTE 7531N`: 中兴远航 30S

**中兴远航 30 畅行版:**

`ZTE 7534N`: 中兴远航 30 畅行版

**中兴远航 30 Pro:**

`ZTE 8040N`: 中兴远航 30 Pro

**中兴远航 30 Pro+:**

`ZTE 9041N`: 中兴远航 30 Pro+

**中兴畅行 30:**

`ZTE 1010L`: 中兴畅行 30

**中兴远航 40:**

`ZTE 7542N`: 中兴远航 40

**中兴远航 40 Pro+:**

`ZTE 9042N`: 中兴远航 40 Pro+

**中兴远航 41:**

`ZTE 7541N`: 中兴远航 41

**中兴远航 41S:**

`ZTE 7546N`: 中兴远航 41S

**中兴畅行 40 SE:**

`ZTE 1021L`: 中兴畅行 40 SE

**中兴小鲜 50 / 中兴畅行 50:**

`ZTE 7543N`: 中兴小鲜 50 / 中兴畅行 50

**中兴小鲜 60 / 中兴远航 60 / 中兴 V80:**

`ZTE 7551N`: 中兴小鲜 60 / 中兴远航 60 / 中兴 V80

**中兴畅行 60:**

`ZTE 7552N`: 中兴畅行 60

**中兴畅行 60 Plus / 中兴远航 61:**

`ZTE 7553N`: 中兴畅行 60 Plus / 中兴远航 61

**中兴畅行 60 Ultra:**

`ZTE 7661N`: 中兴畅行 60 Ultra

**中兴远航 60 Plus / 中兴远航 70 / 中兴小鲜 60 臻情版:**

`ZTE 7561N`: 中兴远航 60 Plus / 中兴远航 70 / 中兴小鲜 60 臻情版

**中兴远航 3D:**

`ZTE 7533N` `Z9101`: 中兴远航 3D

**中兴畅行 70 Plus:**

`ZTE 7671N`: 中兴畅行 70 Plus

**中兴小鲜 70 Plus:**

`ZTE 7672N`: 中兴小鲜 70 Plus

**中兴 V70:**

`ZTE 9041N`: 中兴 V70

**中兴 V70 Pro:**

`ZTE 9043N`: 中兴 V70 Pro

**中兴 Axon Pad:**

`ZTE PA01`: 中兴 Axon Pad

**中兴云电脑:**

`W200DS`: 中兴云电脑 逍遥系列 (公开版)

`W200DS Pro`: 中兴云电脑 逍遥系列 Pro (公开版)

`W201DS`: 中兴云电脑 逍遥系列 (电信定制)

`W202DS` `W203DS`: 中兴云电脑 逍遥系列 (移动定制)

`W205DS`: 中兴云电脑 逍遥系列 (联通定制)

`W210DS`: 中兴云电脑 逍遥 20 (公开版)

`W211DS`: 中兴云电脑 逍遥 20 (电信定制)

`W212DS` `W213DS`: 中兴云电脑 逍遥 20 (移动定制)

`W215S`: 中兴云电脑 逍遥 20 (联通定制)