# OnePlus Mobile Phone Models

- Range: All models
- Codename: ✅

## OnePlus Phones

**OnePlus One (`bacon`):**

`ONE A0001`: OnePlus One China / China Mobile / Global

`ONE A1001`: OnePlus One China Unicom

**OnePlus 2 (`oneplus2`):**

`ONE A2001`: OnePlus 2 China

`ONE A2003`: OnePlus 2 Global

`ONE A2005`: OnePlus 2 North America

**OnePlus X (`onyx`):**

`ONE E1000`: OnePlus X China

`ONE E1001`: OnePlus X China Mobile / China Unicom

`ONE E1003`: OnePlus X Global

`ONE E1005`: OnePlus X North America

**OnePlus 3 (`oneplus3`):**

`ONEPLUS A3000`: OnePlus 3 China / North America

`ONEPLUS A3003`: OnePlus 3 Global

**OnePlus 3T (`oneplus3t`):**

`ONEPLUS A3010`: OnePlus 3T China

`ONEPLUS A3013`: OnePlus 3T Global

**OnePlus 5 (`cheeseburger`):**

`ONEPLUS A5000`: OnePlus 5

**OnePlus 5T (`dumpling`):**

`ONEPLUS A5010`: OnePlus 5T

**OnePlus 6 (`enchilada`):**

`ONEPLUS A6000`: OnePlus 6 China

`ONEPLUS A6003`: OnePlus 6 Global

**OnePlus 6T (`fajita`):**

`ONEPLUS A6010`: OnePlus 6T China

`ONEPLUS A6013`: OnePlus 6T Global

**OnePlus 7 (`guacamoleb`):**

`GM1900`: OnePlus 7 China

`GM1901`: OnePlus 7 India

`GM1903`: OnePlus 7 Europe

`GM1905`: OnePlus 7 North America / Global

**OnePlus 7 Pro (`guacamole`):**

`GM1910`: OnePlus 7 Pro China

`GM1911`: OnePlus 7 Pro India

`GM1913`: OnePlus 7 Pro Europe
 
`GM1915`: OnePlus 7 Pro North America / Global

**OnePlus 7 Pro (`guacamolet`):**

`GM1917`: OnePlus 7 Pro T-Mobile

**OnePlus 7 Pro 5G (`guacamoleg`):**

`GM1920`: OnePlus 7 Pro 5G Europe

**OnePlus 7 Pro 5G (`guacamoles`):**

`GM1925`: OnePlus 7 Pro 5G Sprint

**OnePlus 7T (`hotdogb`):**

`HD1900`: OnePlus 7T China

`HD1901`: OnePlus 7T India

`HD1903`: OnePlus 7T Europe

`HD1905`: OnePlus 7T North America / Global

**OnePlus 7T (`hotdogt`):**

`HD1907`: OnePlus 7T T-Mobile

**OnePlus 7T Pro (`hotdog`):**

`HD1910`: OnePlus 7T Pro China

`HD1911`: OnePlus 7T Pro India

`HD1913`: OnePlus 7T Pro Europe / Global

**OnePlus 7T Pro 5G (`hotdogg`):**

`HD1925`: OnePlus 7T Pro 5G T-Mobile / OnePlus Concept One

**OnePlus 8 (`instantnoodle`):**

`IN2010`: OnePlus 8 China

`IN2011`: OnePlus 8 India

`IN2013`: OnePlus 8 Europe

`IN2015`: OnePlus 8 North America / Global

**OnePlus 8 (`instantnoodlet`):**

`IN2017`: OnePlus 8 T-Mobile

**OnePlus 8 (`instantnoodlevis`):**

`IN2019`: OnePlus 8 Visible / Verzion

**OnePlus 8 Pro (`instantnoodlep`):**

`IN2020`: OnePlus 8 Pro China

`IN2021`: OnePlus 8 Pro India

`IN2023`: OnePlus 8 Pro Europe

`IN2025`: OnePlus 8 Pro North America / Global

**OnePlus 8T (`kebab`):**

`KB2000`: OnePlus 8T China

`KB2001`: OnePlus 8T India

`KB2003`: OnePlus 8T Europe

`KB2005`: OnePlus 8T North America / Global / OnePlus 8T Concept

**OnePlus 8T+ (`kebabt`):**

`KB2007`: OnePlus 8T+ T-Mobile

**OnePlus 9R (`lemonades`):**

`LE2100`: OnePlus 9R China

`LE2101`: OnePlus 9R India

**OnePlus 9 (`lemonade`):**

`LE2110`: OnePlus 9 China

`LE2111`: OnePlus 9 India

`LE2113`: OnePlus 9 Europe

`LE2115`: OnePlus 9 North America / Global

**OnePlus 9 (`lemonadet`):**

`LE2117`: OnePlus 9 T-Mobile

**OnePlus 9 (`lemonadev`):**

`LE2119`: OnePlus 9 Verzion

**OnePlus 9 Pro (`lemonadep`):**

`LE2120`: OnePlus 9 Pro China

`LE2121`: OnePlus 9 Pro India

`LE2123`: OnePlus 9 Pro Europe

`LE2125`: OnePlus 9 Pro North America / Global

**OnePlus 9 Pro (`lemonadept`):**

`LE2127`: OnePlus 9 Pro T-Mobile

**OnePlus 9RT (`martini`):**

`MT2110`: OnePlus 9RT China

`MT2111`: OnePlus 9RT India

**OnePlus 10 Pro (`negroni`):**

`NE2210`: OnePlus 10 Pro China

`NE2211`: OnePlus 10 Pro India

`NE2213`: OnePlus 10 Pro Europe / Global

`NE2215`: OnePlus 10 Pro North America

`NE2217`: OnePlus 10 Pro T-Mobile

**OnePlus 10R / OnePlus Ace (`pickle`):**

`PGKM10`: OnePlus Ace China

`CPH2423`: OnePlus 10R India

`CPH2411`: OnePlus 10R Endurance India

**OnePlus Ace Race (`qqcandy`):**

`PGZ110`: OnePlus Ace Race China

**OnePlus 10T / OnePlus Ace Pro (`ovaltine`):**

`PGP110`: OnePlus Ace Pro China / Genshin Impact Edition

`CPH2413`: OnePlus 10T India

`CPH2415`: OnePlus 10T Europe / Global

`CPH2417`: OnePlus 10T North America

`CPH2419`: OnePlus 10T T-Mobile

**OnePlus 11 (`salami`):**

`PHB110`: OnePlus 11 China

`CPH2447`: OnePlus 11 India

`CPH2449`: OnePlus 11 Europe / Global / OnePlus 11 Concept

`CPH2451`: OnePlus 11 North America

**OnePlus 11R / OnePlus Ace 2 (`udon`):**

`PHK110`: OnePlus Ace 2 China / Genshin Impact Edition

`CPH2487`: OnePlus 11R India

**OnePlus Ace 2V / OnePlus Nord 3 (`vitamin`):**

`PHP110`: OnePlus Ace 2V China

`CPH2491`: OnePlus Nord 3 India

`CPH2493`: OnePlus Nord 3 Europe

**OnePlus Ace 2 Pro (`xigua`) / OnePlus Ace 2 Pro Genshin Impact (`xiyou`):**

`PJA110`: OnePlus Ace 2 Pro China / Genshin Impact Edition

**OnePlus 12 (`waffle`):**

`PJD110`: OnePlus 12 China

`CPH2573`: OnePlus 12 India

`CPH2581`: OnePlus 12 Europe / Global

`CPH2583`: OnePlus 12 North America

**OnePlus Ace 3 / OnePlus 12R (`aston`) / OnePlus Ace 3 Genshin Impact Edition / OnePlus 12R Genshin Impact Edition (`martin`):**

`PJE110`: OnePlus Ace 3 China / Genshin Impact Edition

`CPH2585`: OnePlus 12R India / Genshin Impact Edition

`CPH2609`: OnePlus 12R Europe / Global / Genshin Impact Edition

`CPH2611`: OnePlus 12R North America / Genshin Impact Edition

**OnePlus Ace 3V (`audi`):**

`PJF110`: OnePlus Ace 3V China

**OnePlus Ace 3 Pro (`corvette`):**

`PJX110`: OnePlus Ace 3 Pro China

**OnePlus 13 (`dodge`):**

`PJZ110`: OnePlus 13 China

`CPH2649`: OnePlus 13 India

`CPH2653`: OnePlus 13 Europe / Global

`CPH2655`: OnePlus 13 North America

**OnePlus Ace 5 / OnePlus 13R (`giulia`):**

`PKG110`: OnePlus Ace 5 China

`CPH2645`: OnePlus 13R Europe / Global

`CPH2647`: OnePlus 13R North America

`CPH2691`: OnePlus 13R India

**OnePlus Ace 5 Pro (`hummer`):**

`PKR110`: OnePlus Ace 5 Pro China

**OnePlus Ace 5 Ultra (`emira`):**

`PLC110`: OnePlus Ace 5 Ultra China

**OnePlus Ace 5 Race (`subaru`):**

`PLF110`: OnePlus Ace 5 Race China

**OnePlus 13T / OnePlus 13s (`pagani`):**

`PKX110`: OnePlus 13T China

`CPH2723`: OnePlus 13s India

**OnePlus 15 (`infiniti`):**

`PLK110`: OnePlus 15 China

`CPH2745`: OnePlus 15 India

`CPH2747`: OnePlus 15 Europe / Global

`CPH2749`: OnePlus 15 North America

**OnePlus Ace 6 (`ktm`):**

`PLQ110`: OnePlus Ace 6 China

**OnePlus Ace 6T / OnePlus 15R (`macan`):**

`PLR110`: OnePlus Ace 6T China

`CPH2767`: OnePlus 15R India

`CPH2769`: OnePlus 15R Europe / Global

`CPH2771`: OnePlus 15R North America

**OnePlus 15T (`fairlady`):**

`PLZ110`: OnePlus 15T China

**OnePlus Ace 6 Ultra (`roadster`):**

`PMB110`: OnePlus Ace 6 Ultra China

**OnePlus Turbo 6 / OnePlus Nord 6 (`volkswagen`):**

`PLU110`: OnePlus Turbo 6 China

`CPH2793`: OnePlus Nord 6 India

`CPH2795`: OnePlus Nord 6 Global

**OnePlus Turbo 6V / OnePlus Nord CE 6 (`prado`):**

`PLY110`: OnePlus Turbo 6V China

`CPH2805`: OnePlus Nord CE 6 India

`CPH2807`: OnePlus Nord CE 6 Global

**OnePlus Turbo 6X (`kof`):**

`PYS110`: OnePlus Turbo 6X China

**OnePlus Turbo 6X Pro (`lol`):**

`PYR110`: OnePlus Turbo 6X Pro China

**OnePlus Nord (`avicii`):**

`AC2001`: OnePlus Nord India

`AC2003`: OnePlus Nord Europe / Global

**OnePlus Nord 2 (`denniz`):**

`DN2101`: OnePlus Nord 2 India

`DN2103`: OnePlus Nord 2 Europe

**OnePlus Nord 2T (`karen`):**

`CPH2399`: OnePlus Nord 2T Global

`CPH2401`: OnePlus Nord 2T India

**OnePlus Nord 4 (`avalon`):**

`CPH2661`: OnePlus Nord 4 India

`CPH2663`: OnePlus Nord 4 Europe / Global

**OnePlus Nord 5 (`lexus`):**

`CPH2707`: OnePlus Nord 5 India

`CPH2709`: OnePlus Nord 5 Global

**OnePlus Nord CE (`ebba`):**

`EB2101`: OnePlus Nord CE India

`EB2103`: OnePlus Nord CE Europe / Global

**OnePlus Nord CE 2 (`ivan`):**

`IV2201`: OnePlus Nord CE 2 India

**OnePlus Nord CE 2 Lite (`oscar`):**

`CPH2381`: OnePlus Nord CE 2 Lite India

`CPH2409`: OnePlus Nord CE 2 Lite Europe / Global

**OnePlus Nord CE 3 (`ziti`):**

`CPH2569`: OnePlus Nord CE 3 India

**OnePlus Nord CE 3 Lite / OnePlus Nord N30 (`larry`):**

`CPH2465`: OnePlus Nord CE 3 Lite Global

`CPH2467`: OnePlus Nord CE 3 Lite India

`CPH2513`: OnePlus Nord N30 North America

`CPH2515`: OnePlus Nord N30 T-Mobile

**OnePlus Nord CE 4 (`benz`):**

`CPH2613`: OnePlus Nord CE 4 India

**OnePlus Nord CE 4 Lite (`camry`):**

`CPH2619`: OnePlus Nord CE 4 Lite India

`CPH2621`: OnePlus Nord CE 4 Lite Europe / Global

**OnePlus Nord CE 5 (`honda`):**

`CPH2717`: OnePlus Nord CE 5 India

`CPH2719`: OnePlus Nord CE 5 Global

**OnePlus Nord CE 6 Lite (`suzuki-o`):**

`CPH2943`: OnePlus Nord CE 6 Lite India

**OnePlus N6:**

`CPH2955`: OnePlus N6 India

**OnePlus Nord N10 (`billie8`):**

`BE2025`: OnePlus Nord N10 Metro

`BE2026`: OnePlus Nord N10 North America

`BE2029`: OnePlus Nord N10 Europe / Global

**OnePlus Nord N10 (`billie8t`):**

`BE2028`: OnePlus Nord N10 T-Mobile

**OnePlus Nord N100 (`bengal`):**

`BE2011`: OnePlus Nord N100 North America

`BE2012`: OnePlus Nord N100 T-Mobile

`BE2013`: OnePlus Nord N100 Global

`BE2015`: OnePlus Nord N100 Metro

**OnePlus Nord N20 (`gunnar`):**

`GN2200`: OnePlus Nord N20

`CPH2459`: OnePlus Nord N20

**OnePlus Nord N20 SE (`zhaoyun-o`):**

`CPH2469`: OnePlus Nord 20 SE

**OnePlus Nord N30 SE (`fanli-o`):**

`CPH2605`: OnePlus Nord N30 SE Europe

**OnePlus Nord N200 (`dre9`):**

`DE2117`: OnePlus Nord N200 North America

**OnePlus Nord N200 (`dre8t`):**

`DE2118`: OnePlus Nord N200 T-Mobile

**OnePlus Nord N300 (`hilda`):**

`CPH2389`: OnePlus Nord N300

**OnePlus Open (`hedwig`) (`xueying-9`):**

`CPH2551`: OnePlus Open

## OnePlus Tablets

**OnePlus Pad (2023) (`aries-o`):**

`OPD2203`: OnePlus Pad (2023) Global

**OnePlus Pad Go (`bluey-o`):**

`OPD2304`: OnePlus Pad Go LTE

`OPD2305`: OnePlus Pad Go Wi-Fi

**OnePlus Pad (2024) (`dunhuang-o`):**

`OPD2407`: OnePlus Pad (2024) China

**OnePlus Pad 2 (2024) / OnePlus Pad Pro (`rainbow`) (`caihong-o`):**

`OPD2404`: OnePlus Pad Pro China

`OPD2403`: OnePlus Pad 2 (2024) Global

**OnePlus Pad 3 / OnePlus Pad 2 Pro (`erhai-o`):**

`OPD2413`: OnePlus Pad 2 Pro China

`OPD2415`: OnePlus Pad 3 Global

**OnePlus Pad Lite (`fiji-o`):**

`OPD2480`: OnePlus Pad Lite Wi-Fi

`OPD2481`: OnePlus Pad Lite LTE

**OnePlus Pad Go 2 (`greenland-o`):**

`OPD2504`: OnePlus Pad Go 2 Wi-Fi

`OPD2505`: OnePlus Pad Go 2 5G

**OnePlus Pad 2 (2025) (`himalayan-o`):**

`OPD2508`: OnePlus Pad 2 (2025) China

**OnePlus Pad 3 Pro / OnePlus Pad 4 (`iceland-o`):**

`OPD2513`: OnePlus Pad 3 Pro China

`OPD2514`: OnePlus Pad 4 Global

## OnePlus Wearables

**OnePlus Band (`audio`):**

`W101IN`: OnePlus Band India

**OnePlus Nord Watch (`newton`):**

`OPBBE221`: OnePlus Nord Watch

**OnePlus Watch:**

`W301CN`: OnePlus Watch China / Cyberpunk 2077 Limited Edition

`W501CN`: OnePlus Watch Cobalt Limited Edition (China)

`W301GB`: OnePlus Watch Global / Cobalt Limited Edition (Global) / Harry Potter Limited Edition

**OnePlus Watch 2R / OnePlus Watch 2 China (`bagel`):**

`OPWW234`: OnePlus Watch 2 (China)

`OPWWE234`: OnePlus Watch 2R

**OnePlus Watch 2 (`almond`):**

`OPWWE231`: OnePlus Watch 2 (Global)

**OnePlus Watch 3 (`chili`) (`chilie`):**

~`OPWW251`: OnePlus Watch 3 (China)~

`OPWWE251`: OnePlus Watch 3 (Global)

`OPWE242`: OnePlus Watch 3 43mm (Global)

**OnePlus Watch 4:**

`OPWWE261`: OnePlus Watch 4 (Global)
