# OPPO 手机型号汇总

- 汇总范围: 2018 年起新型号命名方式的国行机型
- codename: ⏹
- 是否包含海外机型: [单独汇总 (英文)](/brands/oppo_global_en.md)

## Find X 系列

**OPPO Find X:**

`PAFM00`: OPPO Find X 标准版 全网通版

`PAFT00`: OPPO Find X 标准版 移动版

`PAHM00`: OPPO Find X 超级闪充版/兰博基尼版 全网通版

`PAFT10`: OPPO Find X 超级闪充版 移动版

**OPPO Find X2:**

`PDEM10`: OPPO Find X2 全网通版

`PDET10`: OPPO Find X2 移动版

**OPPO Find X2 Pro:**

`PDEM30`: OPPO Find X2 Pro

**OPPO Find X3 (`horee`):**

`PEDM00`: OPPO Find X3

**OPPO Find X3 Pro (`fussi`):**

`PEEM00`: OPPO Find X3 Pro

**OPPO Find X3 Pro 摄影师版 (`fluorite`):**

`PEEM00`: OPPO Find X3 Pro 摄影师版

**OPPO Find X5 (`luwu`):**

`PFFM10`: OPPO Find X5

**OPPO Find X5 Pro (`baize`):**

`PFEM10`: OPPO Find X5 Pro

**OPPO Find X5 Pro 天玑版 (`diting`):**

`PFFM20`: OPPO Find X5 Pro 天玑版

**OPPO Find X6 (`luna`):**

`PGFM10`: OPPO Find X6

**OPPO Find X6 Pro (`wukong`):**

`PGEM10`: OPPO Find X6 Pro

**OPPO Find X7 (`nvwa-v`):**

`PHZ110`: OPPO Find X7

**OPPO Find X7 Ultra (`pangu`):**

`PHY110`: OPPO Find X7 Ultra

`PHY120`: OPPO Find X7 Ultra 卫星通信版

**OPPO Find X8 (`yala`):**

`PKB110`: OPPO Find X8

**OPPO Find X8 Pro (`konka`):**

`PKC110`: OPPO Find X8 Pro

`PKC130`: OPPO Find X8 Pro 卫星通信版

**OPPO Find X8s (`koktokay`):**

`PKT110`: OPPO Find X8s

**OPPO Find X8s+ (`slmh`):**

`PLB110`: OPPO Find X8s+

**OPPO Find X8 Ultra (`zhufeng`):**

`PKJ110`: OPPO Find X8 Ultra

`PKU110`: OPPO Find X8 Ultra 卫星通信版

**OPPO Find X9 (`zhujiang`):**

`PLJ110`: OPPO Find X9

**OPPO Find X9 Pro (`changjiang`):**

`PLG110`: OPPO Find X9 Pro

`PLG120`: OPPO Find X9 Pro 卫星通信版

**OPPO Find X9s Pro (`venus`):**

`PME110`: OPPO Find X9s Pro

**OPPO Find X9 Ultra (`lighthouse`):**

`PMA110`: OPPO Find X9 Ultra

`PMA120`: OPPO Find X9 Ultra 卫星通信版

## Find N 系列

**OPPO Find N (`peacock`):**

`PEUM00`: OPPO Find N

**OPPO Find N2 (`whiteswan`):**

`PGU110`: OPPO Find N2

**OPPO Find N2 Flip (`dragonfly`):**

`PGT110`: OPPO Find N2 Flip

**OPPO Find N3 (`xueying`):**

`PHN110`: OPPO Find N3 / OPPO Find N3 典藏版

**OPPO Find N3 Flip (`flamingo`):**

`PHT110`: OPPO Find N3 Flip

**OPPO Find N5 (`petrel`):**

`PKH110`: OPPO Find N5

`PKH120`: OPPO Find N5 卫星通信版

**OPPO Find N6 (`swangoose`):**

`PLP110`: OPPO Find N6

`PLP120`: OPPO Find N6 卫星通信版

## Reno 系列

**OPPO Reno:**

`PCAM00`: OPPO Reno 全网通版

`PCAT00`: OPPO Reno 移动版

**OPPO Reno 10 倍变焦版:**

`PCCM00`: OPPO Reno 10 倍变焦版 全网通版

`PCCT00`: OPPO Reno 10 倍变焦版 移动版

**OPPO Reno Z:**

`PCDM10`: OPPO Reno Z 全网通版

`PCDT10`: OPPO Reno Z 移动版

**OPPO Reno2:**

`PCKM00`: OPPO Reno2 全网通版

`PCKT00`: OPPO Reno2 移动版

**OPPO Reno2 Z:**

`PCKM80`: OPPO Reno2 Z 全网通版

`PCKT80`: OPPO Reno2 Z 移动版

**OPPO Reno3:**

`PDCM00`: OPPO Reno3 全网通版

`PDCT00`: OPPO Reno3 移动版

**OPPO Reno3 Pro:**

`PCRM00`: OPPO Reno3 Pro 全网通版

`PCRT00`: OPPO Reno3 Pro 移动版

**OPPO Reno3 元气版:**

`PCLM50`: OPPO Reno3 元气版 全网通版

`PCRT01`: OPPO Reno3 元气版 移动版

**OPPO Reno4:**

`PDPM00`: OPPO Reno4 全网通版

`PDPT00`: OPPO Reno4 移动版

**OPPO Reno4 Pro:**

`PDNM00`: OPPO Reno4 Pro 全网通版

`PDNT00`: OPPO Reno4 Pro 移动版

**OPPO Reno4 SE:**

`PEAM00`: OPPO Reno4 SE 全网通版

`PEAT00`: OPPO Reno4 SE 移动版

**OPPO Reno5 (`kunlun`):**

`PEGM00`: OPPO Reno5 全网通版

`PEGT00`: OPPO Reno5 移动版

**OPPO Reno5 K (`wudang`):**

`PEGM10`: OPPO Reno5 K 全网通版

`PEGT10`: OPPO Reno5 K 移动版

**OPPO Reno5 Pro (`chaka`):**

`PDSM00`: OPPO Reno5 Pro 全网通版

`PDST00`: OPPO Reno5 Pro 移动版

**OPPO Reno5 Pro+ (`hima`):**

`PDRM00`: OPPO Reno5 Pro+

**OPPO Reno6 (`garen`):**

`PEQM00`: OPPO Reno6

**OPPO Reno6 Pro (`yasuo`):**

`PEPM00`: OPPO Reno6 Pro

**OPPO Reno6 Pro+ (`jin`):**

`PENM00`: OPPO Reno6 Pro+

**OPPO Reno7 (`libai`):**

`PFJM10`: OPPO Reno7

**OPPO Reno7 Pro (`mozi`):**

`PFDM00`: OPPO Reno7 Pro

**OPPO Reno7 SE (`dufu`):**

`PFCM00`: OPPO Reno7 SE

**OPPO Reno8 (`ali`):**

`PGBM10`: OPPO Reno8

**OPPO Reno8 Pro (`wuyi`):**

`PGAM10`: OPPO Reno8 Pro

**OPPO Reno8 Pro+ (`taibai`):**

`PFZM10`: OPPO Reno8 Pro+

**OPPO Reno9 (`lantian`):**

`PHM110`: OPPO Reno9

**OPPO Reno9 Pro (`linhai`):**

`PGX110`: OPPO Reno9 Pro

**OPPO Reno9 Pro+ (`lvzhou`):**

`PGW110`: OPPO Reno9 Pro+

**OPPO Reno10 (`taylor`):**

`PHW110`: OPPO Reno10

**OPPO Reno10 Pro (`viven`):**

`PHV110`: OPPO Reno10 Pro

**OPPO Reno10 Pro+ (`monroe`):**

`PHU110`: OPPO Reno10 Pro+

**OPPO Reno11 (`huahai`):**

`PJH110`: OPPO Reno11

**OPPO Reno11 Pro (`daoxiang`):**

`PJJ110`: OPPO Reno11 Pro

**OPPO Reno12 (`omega`) (`omega-c2`):**

`PJV110`: OPPO Reno12

**OPPO Reno12 Pro (`omega`) (`omega-c1`):**

`PJW110`: OPPO Reno12 Pro

**OPPO Reno13 (`milkyway`) (`milkyway-c2`):**

`PKM110`: OPPO Reno13

**OPPO Reno13 Pro (`milkyway`) (`milkyway-c1`):**

`PKK110`: OPPO Reno13 Pro

**OPPO Reno14 (`zhuque`) (`zhuque-c2`):**

`PLA110`: OPPO Reno14

**OPPO Reno14 Pro (`zhuque`) (`zhuque-c1`):**

`PKZ110`: OPPO Reno14 Pro

**OPPO Reno15 (`whoopass-c2`):**

`PLW110`: OPPO Reno15

**OPPO Reno15 Pro (`whoopass-c1`):**

`PLV110`: OPPO Reno15 Pro

**OPPO Reno15c (`whoopass-c3`):**

`PMD110`: OPPO Reno15c

**OPPO Reno16 (`lychee-c2`):**

`PMM110`: OPPO Reno16

**OPPO Reno16 Pro (`lychee-c1`):**

`PMK110`: OPPO Reno16 Pro

## Ace 系列

**OPPO Reno Ace:**

`PCLM10`: OPPO Reno Ace

**OPPO Ace2:**

`PDHM00`: OPPO Ace2

## R 系列

**OPPO R15:**

`PACM00`: OPPO R15 全网通版

`PACT00`: OPPO R15 移动版

**OPPO R15 梦镜版:**

`PAAM00`: OPPO R15 梦镜版 全网通版

`PAAT00`: OPPO R15 梦镜版 移动版

**OPPO R15x:**

`PBCM10`: OPPO R15x 全网通版

`PBCT10`: OPPO R15x 移动版

**OPPO R17:**

`PBEM00`: OPPO R17 全网通版

`PBET00`: OPPO R17 移动版

**OPPO R17 Pro:**

`PBDM00`: OPPO R17 Pro 全网通版

`PBDT00`: OPPO R17 Pro 移动版

## A 系列

**OPPO A3:**

`PADM00`: OPPO A3 全网通版

`PADT00`: OPPO A3 移动版

**OPPO A5:**

`PBAM00` `PBBM30`: OPPO A5 全网通版

`PBAT00` `PBBT30`: OPPO A5 移动版

**OPPO A7:**

`PBFM00`: OPPO A7 全网通版

`PBFT00`: OPPO A7 移动版

**OPPO A7x:**

`PBBM00`: OPPO A7x 全网通版

`PBBT00`: OPPO A7x 移动版

**OPPO A7n:**

`PCDM00`: OPPO A7n 全网通版

`PCDT00`: OPPO A7n 移动版

**OPPO A8:**

`PDBM00`: OPPO A8 全网通版

`PDBT00`: OPPO A8 移动版

**OPPO A9:**

`PCAM10`: OPPO A9 全网通版

`PCAT10`: OPPO A9 移动版

**OPPO A9x:**

`PCEM00`: OPPO A9x 全网通版

`PCET00`: OPPO A9x 移动版

**OPPO A11:**

`PCHM10`: OPPO A11 全网通版

`PCHT10`: OPPO A11 移动版

**OPPO A11x:**

`PCHM30`: OPPO A11x 全网通版

`PCHT30`: OPPO A11x 移动版

**OPPO A11n:**

`PCHM00`: OPPO A11n 全网通版

`PCHT00`: OPPO A11n 移动版

**OPPO A11s:**

`PDVM00`: OPPO A11s

**OPPO A32:**

`PDVM00`: OPPO A32

**OPPO A35:**

`PEFM00`: OPPO A35

**OPPO A36:**

`PESM10`: OPPO A36

**OPPO A52:**

`PDAM10`: OPPO A52 全网通版

`PDAT10`: OPPO A52 移动版

**OPPO A53:**

`PECM20` `PECM30`: OPPO A53 (2020) 全网通版

`PECT30`: OPPO A53 (2020) 移动版

**OPPO A55:**

`PEMM00` `PEMM20`: OPPO A55 全网通版

`PEMT00` `PEMT20`: OPPO A55 移动版

**OPPO A55s:**

`PEMM00`: OPPO A55s

**OPPO A56:**

`PFVM10`: OPPO A56

**OPPO A56s:**

`PFTM20`: OPPO A56s

**OPPO A57:**

`PFTM20`: OPPO A57 (2022)

**OPPO A58:**

`PHJ110`: OPPO A58

**OPPO A58x:**

`PHJ110`: OPPO A58x

**OPPO A72:**

`PDYM20`: OPPO A72 全网通版

`PDYT20`: OPPO A72 移动版

**OPPO A72n:**

`PDYM10`: OPPO A72n

**OPPO A91:**

`PCPM00`: OPPO A91 全网通版

`PCPT00`: OPPO A91 移动版

**OPPO A92s:**

`PDKM00`: OPPO A92s 全网通版

`PDKT00`: OPPO A92s 移动版

**OPPO A93:**

`PEHM00`: OPPO A93 全网通版

`PEHT00`: OPPO A93 移动版

**OPPO A93s (`odin-a`):**

`PFGM00`: OPPO A93s

**OPPO A95:**

`PELM00`: OPPO A95

**OPPO A96 (`mulan`):**

`PFUM10`: OPPO A96

**OPPO A96 (`mulan-a`):**

`PHA120`: OPPO A96

**OPPO A97 (`alice`):**

`PFTM10`: OPPO A97

**OPPO A1 (`colombo`):**

`PHS110`: OPPO A1 5G (2023)

**OPPO A1 Pro (`hepburn`):**

`PHQ110`: OPPO A1 Pro

**OPPO A1x / OPPO A1 活力版 (`lijing`):**

`PHJ110`: OPPO A1x / OPPO A1 活力版

**OPPO A1s / OPPO A2 (`fanli`):**

`PJB110`: OPPO A1s / OPPO A2

**OPPO A1i / OPPO A2m (`lijing-a`):**

`PJU110`: OPPO A1i / OPPO A2m

**OPPO A2x (`lijing-a`):**

`PJS110`: OPPO A2x

**OPPO A2 Pro (`givenchy`):**

`PJG110`: OPPO A2 Pro

**OPPO A3 / OPPO A3i Plus (`avatar-m`):**

`PKA110`: OPPO A3 5G (2024) / OPPO A3i Plus

**OPPO A3 活力版 (`avatar-l5`):**

`PKD110`: OPPO A3 活力版

**OPPO A3m:**

`PKD120`: OPPO A3m

**OPPO A3x (`avatar-l5`):**

`PKD130`: OPPO A3x

**OPPO A3i (`avatar-b5`):**

`PKL110`: OPPO A3i

**OPPO A3 Pro / OPPO A5 Plus (`avatar-h`):**

`PJY110`: OPPO A3 Pro / OPPO A5 Plus

**OPPO A5 / OPPO A6 Plus (`alpha-m`):**

`PKQ110`: OPPO A5 5G (2025) / OPPO A6 Plus

**OPPO A5 活力版 (`alpha-l5`):**

`PKV110`: OPPO A5 活力版

**OPPO A5x / OPPO A5m (`alpha-b5`):**

`PKW110`: OPPO A5x / OPPO A5m

**OPPO A5 Pro (`alpha`) (`alpha-h`):**

`PKP110`: OPPO A5 Pro

**OPPO A6 (`baikal-l5`):**

`PLS120`: OPPO A6

**OPPO A6 GT / OPPO A6 Max / OPPO A6l (`baikal-h`):**

`PLL110`: OPPO A6 GT / OPPO A6 Max / OPPO A6l

**OPPO A6 Pro (`baikal-m`):**

`PLN110`: OPPO A6 Pro

**OPPO A6i (`alpha-b5`):**

`PKW120`: OPPO A6i

**OPPO A6s / OPPO A6i+ / OPPO A6k (`baikal-b5`):**

`PLT120`: OPPO A6s / OPPO A6i+ / OPPO A6k

**OPPO A6s Pro (`cruiser-l5`):**

`PMT110`: OPPO A6s Pro

**OPPO A6v (`baikal-b5`):**

`PLT130`: OPPO A6v

**OPPO A6x / OPPO A6m (`baikal-b5`):**

`PLT140`: OPPO A6x / OPPO A6m

**OPPO A6c (`baikal-b4`):**

`PMC110`: OPPO A6c

**OPPO A7 Pro Max (`doraemon-m`):**

`PYC110`: OPPO A7 Pro Max

## K 系列

**OPPO K1:**

`PBCM30`: OPPO K1

**OPPO K3:**

`PCGM00`: OPPO K3 全网通版

`PCGT00`: OPPO K3 移动版

**OPPO K5:**

`PCNM00`: OPPO K5 全网通版

`PCNT00`: OPPO K5 移动版

**OPPO K7:**

`PCLM50`: OPPO K7

**OPPO K7x:**

`PERM00`: OPPO K7x

**OPPO K9 (`ciri`):**

`PEXM00`: OPPO K9

**OPPO K9s (`walle`) / OPPO K10 活力版 (`walle-k`):**

`PERM10`: OPPO K9s / OPPO K10 活力版

**OPPO K9 Pro (`tiga`):**

`PEYM00`: OPPO K9 Pro

**OPPO K9x (`apollo-o`):**

`PGCM10`: OPPO K9x

**OPPO K10 (`qqcandy`):**

`PGJM10`: OPPO K10

**OPPO K10 Pro (`eva`):**

`PGIM10`: OPPO K10 Pro

**OPPO K10x (`oscar-y`):**

`PGGM10`: OPPO K10x

**OPPO K11 (`ziti`):**

`PJC110`: OPPO K11

**OPPO K11x (`larry`):**

`PHF110`: OPPO K11x

**OPPO K12 (`benz`):**

`PJR110`: OPPO K12

**OPPO K12 Plus (`jeep`):**

`PKS110`: OPPO K12 Plus

**OPPO K12x (`camry`):**

`PJT110`: OPPO K12x

**OPPO K12s (`knight-l`):**

`PLD110`: OPPO K12s

**OPPO K13s (`baikal-h`):**

`PLL110`: OPPO K13s

**OPPO K13x (`alpha-l5`):**

`PKV110`: OPPO K13x

**OPPO K13 Turbo (`knight`):**

`PLM110`: OPPO K13 Turbo

**OPPO K13 Turbo Pro (`knight-h`):**

`PLE110`: OPPO K13 Turbo Pro

**OPPO K15 (`jinx-m`):**

`PYD110`: OPPO K15

**OPPO K15 Pro (`lux-m`):**

`PMH110`: OPPO K15 Pro

**OPPO K15 Pro+ (`lux-h`):**

`PMG110`: OPPO K15 Pro+

## 平板电脑

**OPPO Pad (`oslo`):**

`OPD2101`: OPPO Pad

**OPPO Pad Air (`reeves`):**

`OPD2102`: OPPO Pad Air

**OPPO Pad 2 (`aries`):**

`OPD2201`: OPPO Pad 2

**OPPO Pad Air2 (`bluey`):**

`OPD2301`: OPPO Pad Air2

**OPPO Pad 3 (`dunhuang`):**

`OPD2405`: OPPO Pad 3

**OPPO Pad 3 Pro (`caihong`):**

`OPD2401`: OPPO Pad 3 Pro

**OPPO Pad 4 Pro (`erhai`):**

`OPD2409`: OPPO Pad 4 Pro

**OPPO Pad SE (`fiji`):**

`OPD2417`: OPPO Pad SE

**OPPO Pad 5 (`himalayan`):**

`OPD2506`: OPPO Pad 5

**OPPO Pad Air5 (`greenland`):**

`OPD2501`: OPPO Pad Air5

**OPPO Pad 5 Pro (`iceland`):**

`OPD2511`: OPPO Pad 5 Pro

**OPPO Pad Mini (`ivy`):**

`OPD2515`: OPPO Pad Mini

**OPPO Pad 6 (`jinggangshan`):**

`OPD2601`: OPPO Pad 6

## Watch/Band 系列

**OPPO Band:**

`OB19B1` `OB19O1`: OPPO Band 运动版

`OB19B1` `OB19O3`: OPPO Band 运动版 (国际版)

`OB19B1` `OB19O7`: OPPO Band 活力版

`OB19B3` `OB19O0`: OPPO Band 时尚版 (NFC 版)

`OB19B3` `OB19O2`: OPPO Band EVA 限定版

`OB19B3` `OB19O8`: OPPO Band 名侦探柯南限定版

**OPPO Band 2 (`haisenberg`):**

`OBB211`: OPPO Band 2 标准版

`OBB213`: OPPO Band 2 NFC 版

**OPPO Watch RX:**

`OR19R1`: OPPO Watch RX / 英雄联盟限定版

**OPPO Watch Free:**

`OWW206`: OPPO Watch Free 标准版

`OWW208`: OPPO Watch Free NFC 版

**OPPO Watch:**

`OW19W1`: OPPO Watch 46mm / EVA 限定版 / 故宫新禧版

`OW19W2`: OPPO Watch 41mm

`OW19W3`: OPPO Watch ECG / 精钢版

**OPPO Watch 2 (`maxwell`):**

`OWW202`: OPPO Watch 2 42mm 蓝牙版

`OW20W1`: OPPO Watch 2 46mm eSIM 版 / 李宁限定版

`OW20W2`: OPPO Watch 2 42mm eSIM 版 / 名侦探柯南限定版

`OW20W3`: OPPO Watch 2 46mm ECG

**OPPO Watch 3 / OPPO Watch SE (`oersted`):**

`OWW213`: OPPO Watch SE

`OWW212`: OPPO Watch 3

`OWW211`: OPPO Watch 3 Pro

**OPPO Watch 4 Pro (`comet`) (`huixing`):**

`OWW221`: OPPO Watch 4 Pro

**OPPO Watch X (`star`) (`hengxing`):**

`OWW231`: OPPO Watch X

**OPPO Watch Sport (`sport`):**

`OWW235`: OPPO Watch Sport

**OPPO Watch X2 Mini (`xingchen`):**

`OWW242`: OPPO Watch X2 Mini

**OPPO Watch X2 (`starriver`) (`xinghe`):**

`OWW251`: OPPO Watch X2

**OPPO Watch S:**

`OWW262`: OPPO Watch S

**OPPO Watch X3 (`taycan`):**

`OWW261`: OPPO Watch X3

**OPPO Watch X3 Mini:**

`OWW263`: OPPO Watch X3 Mini